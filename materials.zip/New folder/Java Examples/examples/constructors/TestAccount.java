class TestAccount{
		public static void main(String[] args){
				Account a=new Account(101,"Pennant",40000);
				a.deposit(34000);
				a.withdraw(23000);
				a.withdraw(60000);
		}
}