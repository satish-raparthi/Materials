class CurrentAccount extends Account{

	public void withdraw(double amt){
			
			System.out.println("Current Account implementatn of wthdraw");
	}

	public void calODInt(){
		System.out.println("OD Calculaton");
	
	}
}