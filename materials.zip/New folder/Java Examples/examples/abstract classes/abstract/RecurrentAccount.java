class RecurrentAccount extends Account{

	public void withdraw(double amt){
			
			System.out.println("Recurrent class implementatn of wthdraw");
	}

	public void calMatAmount(){
		System.out.println("Mat Amount calculatn");
	
	}
}