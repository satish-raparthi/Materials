class SavingsAccount extends Account{

	public void withdraw(double amt){
			
			System.out.println("Savngs class implementatn of wthdraw");
	}

	public void transferFunds(){
		System.out.println("Transfer of funds");
	
	}
}